/*
    Summary:
    This program implements a Graph using an adjacency matrix
    and performs Depth First Search (DFS) and Breadth First Search (BFS).

    DFS uses recursion to explore the graph deeply.
    BFS uses a queue to explore the graph level by level.

    Time Complexity of DFS: O(V^2) using adjacency matrix.
    Time Complexity of BFS: O(V^2) using adjacency matrix.
*/


/*
 Algorithm for DFS:

 1. Start the algorithm.
 2. Read the number of vertices.
 3. Read the adjacency matrix.
 4. Mark the starting vertex as visited.
 5. Display the vertex.
 6. Visit every unvisited adjacent vertex recursively.
 7. Stop when all reachable vertices are visited.


 Algorithm for BFS:

 1. Start the algorithm.
 2. Read the number of vertices.
 3. Read the adjacency matrix.
 4. Create a queue.
 5. Mark the starting vertex as visited and insert it into the queue.
 6. Remove a vertex from the queue and display it.
 7. Insert all unvisited adjacent vertices into the queue.
 8. Repeat until the queue becomes empty.
 9. Stop the algorithm.
*/


#include <stdio.h>

#define MAX 100

int graph[MAX][MAX];
int visited[MAX];
int n;


// ---------- DFS ----------
void DFS(int vertex)
{
    printf("%d ", vertex);

    visited[vertex] = 1;

    for (int i = 0; i < n; i++)
    {
        if (graph[vertex][i] == 1 && !visited[i])
        {
            DFS(i);
        }
    }
}


// ---------- BFS ----------
void BFS(int start)
{
    int queue[MAX];
    int front = 0;
    int rear = 0;

    // Reset visited array
    for (int i = 0; i < n; i++)
        visited[i] = 0;

    queue[rear++] = start;
    visited[start] = 1;

    while (front < rear)
    {
        int vertex = queue[front++];

        printf("%d ", vertex);

        for (int i = 0; i < n; i++)
        {
            if (graph[vertex][i] == 1 && !visited[i])
            {
                queue[rear++] = i;
                visited[i] = 1;
            }
        }
    }
}


// ---------- MAIN FUNCTION ----------
int main()
{
    int start;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &graph[i][j]);
        }
    }

    printf("Enter starting vertex (0 to %d): ", n - 1);
    scanf("%d", &start);

    // DFS
    for (int i = 0; i < n; i++)
        visited[i] = 0;

    printf("\nDFS Traversal:\n");
    DFS(start);

    // BFS
    printf("\n\nBFS Traversal:\n");
    BFS(start);

    printf("\n");

    return 0;
}


/*
Time Complexity

DFS using Adjacency Matrix:
Best Case:    O(V^2)
Average Case: O(V^2)
Worst Case:   O(V^2)

BFS using Adjacency Matrix:
Best Case:    O(V^2)
Average Case: O(V^2)
Worst Case:   O(V^2)


Space Complexity

DFS:
O(V) for visited array and recursion stack.

BFS:
O(V) for visited array and queue.

Graph:
O(V^2) for the adjacency matrix.
*/


/*
Conclusion:

The graph was successfully implemented using an adjacency matrix.

DFS and BFS graph traversal techniques were successfully implemented.

DFS explores a graph deeply before backtracking, while BFS explores
the graph level by level using a queue.

Using an adjacency matrix, both DFS and BFS have a time complexity
of O(V^2).

DFS uses recursion, whereas BFS uses a queue for traversal.
*/