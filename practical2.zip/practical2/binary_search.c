/*Algorithm

Note: The array must be sorted.

Read the sorted array elements.
Read the key to search.
Set low = 0 and high = n - 1.
Find the middle element.
If the middle element equals the key, display its position.
If the key is smaller, search the left half.
If the key is larger, search the right half.
Repeat until the element is found or low > high.*/

#include <stdio.h>

int main() {
    int arr[100], n, key;
    int low, high, mid, i;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter sorted array elements:\n");
    for(i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Enter element to search: ");
    scanf("%d", &key);

    low = 0;
    high = n - 1;

    while(low <= high) {
        mid = (low + high) / 2;

        if(arr[mid] == key) {
            printf("Element found at position %d\n", mid + 1);
            return 0;
        }
        else if(arr[mid] < key)
            low = mid + 1;
        else
            high = mid - 1;
    }

    printf("Element not found\n");
    return 0;
}


/*Time Complexity
Best Case: O(1) (Element found at the middle)
Average Case: O(log n)
Worst Case: O(log n)
Space Complexity

O(1) (Iterative implementation)*/
