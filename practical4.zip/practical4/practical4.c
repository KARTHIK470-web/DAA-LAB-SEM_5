/*
    Summary:
    This program implements Factorial using Iterative and Recursive methods.

    The Iterative method calculates factorial using a loop.
    The Recursive method calculates factorial by calling the function
    repeatedly until the base condition is reached.

    Both methods have a time complexity of O(n).
    Iterative method uses O(1) auxiliary space.
    Recursive method uses O(n) stack space.
*/


/*
 Algorithm:

 Iterative Method:
 1. Start the algorithm.
 2. Read the number n.
 3. Initialize fact = 1.
 4. Repeat from 1 to n:
       fact = fact * i.
 5. Display the factorial.
 6. Stop the algorithm.

 Recursive Method:
 1. Start the algorithm.
 2. Read the number n.
 3. If n is 0 or 1, return 1.
 4. Otherwise, return n * factorial(n - 1).
 5. Display the factorial.
 6. Stop the algorithm.
*/


#include <stdio.h>


// ---------- ITERATIVE METHOD ----------
unsigned long long factorialIterative(int n)
{
    unsigned long long fact = 1;

    for (int i = 1; i <= n; i++)
    {
        fact = fact * i;
    }

    return fact;
}


// ---------- RECURSIVE METHOD ----------
unsigned long long factorialRecursive(int n)
{
    // Base condition
    if (n == 0 || n == 1)
        return 1;

    // Recursive call
    return n * factorialRecursive(n - 1);
}


// ---------- MAIN FUNCTION ----------
int main()
{
    int n;

    printf("Enter a number: ");
    scanf("%d", &n);

    if (n < 0)
    {
        printf("Factorial is not defined for negative numbers.\n");
        return 0;
    }

    printf("\nFactorial using Iterative Method:\n");
    printf("%d! = %llu\n", n, factorialIterative(n));

    printf("\nFactorial using Recursive Method:\n");
    printf("%d! = %llu\n", n, factorialRecursive(n));

    return 0;
}


/*
Time Complexity

Iterative Method:
Best Case:    O(n)
Average Case: O(n)
Worst Case:   O(n)

Recursive Method:
Best Case:    O(n)
Average Case: O(n)
Worst Case:   O(n)


Space Complexity

Iterative Method:
O(1)

Recursive Method:
O(n) due to recursive function call stack.
*/


/*
Conclusion:

The factorial program was successfully implemented using both
Iterative and Recursive methods.

The Iterative method calculates factorial using a loop, whereas
the Recursive method calculates factorial using repeated function calls.

Both methods have a Best, Average, and Worst-case time complexity
of O(n).

The Iterative method requires O(1) auxiliary space, while the
Recursive method requires O(n) stack space.

Therefore, the iterative method is more space-efficient, while
the recursive method provides a simple and direct implementation
of the factorial definition.
*/