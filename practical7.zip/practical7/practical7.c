/*
    Summary:
    This program implements the Coin Change / Making Change
    Problem using Dynamic Programming.

    The objective is to find the minimum number of coins required
    to make a given amount.

    Dynamic Programming is used to store the minimum number of
    coins required for each amount.

    Time Complexity: O(n * amount)
    Space Complexity: O(amount)
*/


/*
 Algorithm:

 1. Start the algorithm.
 2. Read the number of coin denominations n.
 3. Read the coin denominations.
 4. Read the required amount.
 5. Create a DP array of size amount + 1.
 6. Initialize dp[0] = 0 and all other values to infinity.
 7. For every amount from 1 to the required amount:
       Check every coin.
       If the coin can be used:
           Update the minimum number of coins.
 8. Display the minimum number of coins.
 9. Stop the algorithm.
*/


#include <stdio.h>
#include <limits.h>

int min(int a, int b)
{
    return (a < b) ? a : b;
}


int main()
{
    int n, amount;

    printf("Enter number of coin denominations: ");
    scanf("%d", &n);

    int coins[n];

    printf("Enter coin denominations:\n");
    for (int i = 0; i < n; i++)
        scanf("%d", &coins[i]);

    printf("Enter amount: ");
    scanf("%d", &amount);

    int dp[amount + 1];

    dp[0] = 0;

    // Initialize DP array
    for (int i = 1; i <= amount; i++)
        dp[i] = INT_MAX - 1;

    // Calculate minimum coins
    for (int i = 1; i <= amount; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (coins[j] <= i)
            {
                dp[i] = min(dp[i],
                            1 + dp[i - coins[j]]);
            }
        }
    }

    if (dp[amount] >= INT_MAX - 1)
        printf("\nChange cannot be made for the given amount.\n");
    else
        printf("\nMinimum number of coins required = %d\n",
               dp[amount]);

    return 0;
}


/*
Time Complexity

Best Case:    O(n * amount)
Average Case: O(n * amount)
Worst Case:   O(n * amount)


Space Complexity

O(amount)
*/


/*
Conclusion:

The Making Change Problem was successfully implemented using
Dynamic Programming.

The algorithm finds the minimum number of coins required to
make the given amount.

The time complexity is O(n * amount) and the space complexity
is O(amount).
*/