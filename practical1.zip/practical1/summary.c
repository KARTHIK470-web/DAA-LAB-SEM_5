/*
    Summary:
    Implementation and time analysis of Bubble, Selection, Insertion,
    Merge and Quick Sort algorithms.
*/