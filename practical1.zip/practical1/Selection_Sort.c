/*Definition

Selection Sort repeatedly finds the smallest element from the unsorted part of the array and places it at the beginning.

Algorithm
Assume the first unsorted element is the minimum.
Compare it with all remaining unsorted elements.
Find the smallest element.
Swap it with the first unsorted element.
Repeat until the array is sorted.#include <stdio.h>*/

int main() {
    int arr[] = {5, 3, 8, 4, 2};
    int n = 5, i, j, min, temp;

    for(i = 0; i < n - 1; i++) {
        min = i;
        for(j = i + 1; j < n; j++) {
            if(arr[j] < arr[min])
                min = j;
        }

        temp = arr[i];
        arr[i] = arr[min];
        arr[min] = temp;
    }

    printf("Sorted Array: ");
    for(i = 0; i < n; i++)
        printf("%d ", arr[i]);

    return 0;
}
/*
Time Complexity
Best Case: O(n�)
Average Case: O(n�)
Worst Case: O(n�)
Space Complexity
O(1)*/
