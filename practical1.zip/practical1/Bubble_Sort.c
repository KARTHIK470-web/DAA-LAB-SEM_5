/*
1. Bubble Sort

Bubble Sort repeatedly compares adjacent elements and swaps them if they are in the wrong order. After each pass, the largest element moves to its correct position.

Algorithm
Start with the first element of the array.
Compare each pair of adjacent elements.
If the left element is greater than the right element, swap them.
Repeat for all adjacent pairs until the end of the array.
Continue passes until the array is sorted.*/


#include <stdio.h>
int main() {
    int arr[] = {5, 3, 8, 4, 2};
    int n = 5, i, j, temp;

    for(i = 0; i < n - 1; i++) {
        for(j = 0; j < n - i - 1; j++) {
            if(arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    printf("Sorted Array: ");
    for(i = 0; i < n; i++)
        printf("%d ", arr[i]);

    return 0;
}


/*
Time Complexity:-
Best Case: O(n)
Average Case: O(n²)
Worst Case: O(n²)

Space Complexity :-
O(1)
*/
