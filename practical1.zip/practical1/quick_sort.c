/*Definition

Quick Sort also uses the Divide and Conquer technique. It selects a pivot, partitions the array, and recursively sorts the partitions.

Algorithm
Choose a pivot element.
Partition the array into smaller and larger elements.
Place the pivot in its correct position.
Recursively sort the left subarray.
Recursively sort the right subarray.*/

#include <stdio.h>

int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = low - 1, j, temp;

    for(j = low; j < high; j++) {
        if(arr[j] < pivot) {
            i++;
            temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }

    temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;

    return i + 1;
}

void quickSort(int arr[], int low, int high) {
    if(low < high) {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main() {
    int arr[] = {5, 3, 8, 4, 2};
    int n = 5, i;

    quickSort(arr, 0, n - 1);

    printf("Sorted Array: ");
    for(i = 0; i < n; i++)
        printf("%d ", arr[i]);

    return 0;
}
/*
Time Complexity
Best Case: O(n log n)
Average Case: O(n log n)
Worst Case: O(n�) (when the pivot is always the smallest or largest element)

Space Complexity
Average: O(log n)
Worst: O(n)
*/


