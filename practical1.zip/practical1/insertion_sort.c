/*
Definition

Insertion Sort builds the sorted array one element at a time by inserting each element into its correct position.

Algorithm
Consider the first element sorted.
Pick the next element (key).
Compare it with previous elements.
Shift larger elements to the right.
Insert the key into its correct position.*/


#include <stdio.h>

int main() {
    int arr[] = {5, 3, 8, 4, 2};
    int n = 5, i, j, key;

    for(i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;

        while(j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }

        arr[j + 1] = key;
    }

    printf("Sorted Array: ");
    for(i = 0; i < n; i++)
        printf("%d ", arr[i]);

    return 0;
}

/*
Time Complexity
Best Case: O(n)
Average Case: O(n�)
Worst Case: O(n�)
Space Complexity
O(1)
*/
