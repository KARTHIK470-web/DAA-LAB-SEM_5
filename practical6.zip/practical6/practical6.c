/*
    Summary:
    This program implements Matrix Chain Multiplication using
    Dynamic Programming.

    The objective is to find the minimum number of scalar
    multiplications required to multiply a chain of matrices.

    Dynamic Programming is used to find the optimal parenthesization.

    Time Complexity: O(n^3)
    Space Complexity: O(n^2)
*/


/*
 Algorithm:

 1. Start the algorithm.
 2. Read the number of matrices n.
 3. Read the dimensions of the matrices.
 4. Create a DP table m[n][n].
 5. Set m[i][i] = 0 for all matrices.
 6. Consider chains of length 2, 3, ..., n.
 7. For every possible split position k:
       Calculate the multiplication cost.
 8. Store the minimum cost in m[i][j].
 9. Display the minimum number of scalar multiplications.
10. Stop the algorithm.
*/


#include <stdio.h>
#include <limits.h>

int main()
{
    int n;

    printf("Enter number of matrices: ");
    scanf("%d", &n);

    int p[n + 1];

    printf("Enter matrix dimensions:\n");
    printf("For %d matrices, enter %d dimensions:\n", n, n + 1);

    for (int i = 0; i <= n; i++)
        scanf("%d", &p[i]);

    int m[n + 1][n + 1];

    // Cost of multiplying one matrix is zero
    for (int i = 1; i <= n; i++)
        m[i][i] = 0;

    // Chain length
    for (int length = 2; length <= n; length++)
    {
        for (int i = 1; i <= n - length + 1; i++)
        {
            int j = i + length - 1;

            m[i][j] = INT_MAX;

            for (int k = i; k < j; k++)
            {
                int cost = m[i][k]
                         + m[k + 1][j]
                         + p[i - 1] * p[k] * p[j];

                if (cost < m[i][j])
                    m[i][j] = cost;
            }
        }
    }

    printf("\nMinimum number of scalar multiplications = %d\n",
           m[1][n]);

    return 0;
}


/*
Time Complexity

Best Case:    O(n^3)
Average Case: O(n^3)
Worst Case:   O(n^3)


Space Complexity

O(n^2)
*/


/*
Conclusion:

The Matrix Chain Multiplication problem was successfully
implemented using Dynamic Programming.

The algorithm finds the optimal order of matrix multiplication
that minimizes the number of scalar multiplications.

The time complexity is O(n^3) and the space complexity is O(n^2).
*/