/*
    Summary:
    This program implements Max-Heap Sort and Min-Heap Sort.
    Max-Heap Sort uses a Max Heap to sort the elements in ascending order.
    Min-Heap Sort uses a Min Heap and reverses the result to get ascending order.
    Both algorithms have a time complexity of O(n log n).
    Heap Sort is an in-place sorting algorithm.
*/


/*
 Algorithm:
Start the algorithm.
Read the number of elements n and the input array.
Build a Max Heap from the given array.
Set the last element as the current heap boundary.
Swap the root element (maximum element) with the last element of the heap.
Reduce the heap size by one.
Apply Max Heapify to the root to restore the Max Heap property.
Repeat Steps 5–7 until the heap size becomes 1.
Display the sorted array in ascending order.
Stop the algorithm.*/

#include <stdio.h>

// Swap function
void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

// ---------- MAX HEAP ----------
void maxHeapify(int arr[], int n, int i)
{
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest])
        largest = left;

    if (right < n && arr[right] > arr[largest])
        largest = right;

    if (largest != i)
    {
        swap(&arr[i], &arr[largest]);
        maxHeapify(arr, n, largest);
    }
}

void maxHeapSort(int arr[], int n)
{
    // Build Max Heap
    for (int i = n / 2 - 1; i >= 0; i--)
        maxHeapify(arr, n, i);

    // Heap Sort
    for (int i = n - 1; i > 0; i--)
    {
        swap(&arr[0], &arr[i]);
        maxHeapify(arr, i, 0);
    }
}

// ---------- MIN HEAP ----------
void minHeapify(int arr[], int n, int i)
{
    int smallest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] < arr[smallest])
        smallest = left;

    if (right < n && arr[right] < arr[smallest])
        smallest = right;

    if (smallest != i)
    {
        swap(&arr[i], &arr[smallest]);
        minHeapify(arr, n, smallest);
    }
}

void reverseArray(int arr[], int n)
{
    int i = 0, j = n - 1;

    while (i < j)
    {
        swap(&arr[i], &arr[j]);
        i++;
        j--;
    }
}

void minHeapSort(int arr[], int n)
{
    // Build Min Heap
    for (int i = n / 2 - 1; i >= 0; i--)
        minHeapify(arr, n, i);

    // Heap Sort
    for (int i = n - 1; i > 0; i--)
    {
        swap(&arr[0], &arr[i]);
        minHeapify(arr, i, 0);
    }

    // Reverse for Ascending Order
    reverseArray(arr, n);
}

// Print array
void printArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

// Main Function
int main()
{
    int n;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    int arr1[n], arr2[n];

    printf("Enter %d elements:\n", n);

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr1[i]);
        arr2[i] = arr1[i];
    }

    printf("\nOriginal Array:\n");
    printArray(arr1, n);

    maxHeapSort(arr1, n);
    printf("\nAfter Max Heap Sort (Ascending):\n");
    printArray(arr1, n);

    minHeapSort(arr2, n);
    printf("\nAfter Min Heap Sort (Ascending):\n");
    printArray(arr2, n);

    return 0;
}
/*
Time Complexity

Best Case: O(n log n)
Average Case: O(n log n)
Worst Case: O(n log n)

Space Complexity
O(1) (in-place, excluding recursion stack).
*/


/*Conclusion
Max-Heap Sort and Min-Heap Sort were successfully implemented.
The Max Heap places the largest element at the root of the heap.
The Min Heap places the smallest element at the root of the heap.
Max-Heap Sort produces the sorted array in ascending order by moving the maximum element to the end.
Min-Heap Sort produces ascending order by reversing the result after sorting.
The heapify() operation is used to maintain the heap property.
Both algorithms have a Best, Average, and Worst-case time complexity of O(n log n).
Heap Sort is an in-place sorting algorithm, requiring O(1) auxiliary array space, excluding recursion stack.
Heap Sort is not a stable sorting algorithm.
Therefore, Heap Sort is an efficient sorting technique for large datasets.*/
