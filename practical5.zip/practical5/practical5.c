/*
    Summary:
    This program implements the 0/1 Knapsack Problem using
    Dynamic Programming.

    In the 0/1 Knapsack problem, each item can either be selected
    completely or not selected.

    The objective is to maximize the total profit without exceeding
    the given knapsack capacity.

    Time Complexity: O(n * W)
    Space Complexity: O(n * W)
*/


/*
 Algorithm:

 1. Start the algorithm.
 2. Read the number of items n.
 3. Read the weights and profits of all items.
 4. Read the maximum capacity W of the knapsack.
 5. Create a DP table of size (n+1) x (W+1).
 6. Initialize the first row and first column with 0.
 7. For every item and capacity:
       If the item's weight is less than or equal to the capacity:
           Choose the maximum of:
           a) Including the current item.
           b) Excluding the current item.
       Otherwise:
           Exclude the current item.
 8. Display the maximum profit.
 9. Stop the algorithm.
*/


#include <stdio.h>

int max(int a, int b)
{
    return (a > b) ? a : b;
}


int main()
{
    int n, W;

    printf("Enter number of items: ");
    scanf("%d", &n);

    int weight[n], profit[n];

    printf("Enter weights of items:\n");
    for (int i = 0; i < n; i++)
        scanf("%d", &weight[i]);

    printf("Enter profits of items:\n");
    for (int i = 0; i < n; i++)
        scanf("%d", &profit[i]);

    printf("Enter capacity of knapsack: ");
    scanf("%d", &W);

    int dp[n + 1][W + 1];

    // Initialize DP table
    for (int i = 0; i <= n; i++)
    {
        for (int w = 0; w <= W; w++)
        {
            if (i == 0 || w == 0)
                dp[i][w] = 0;

            else if (weight[i - 1] <= w)
            {
                dp[i][w] = max(
                    profit[i - 1] + dp[i - 1][w - weight[i - 1]],
                    dp[i - 1][w]
                );
            }

            else
            {
                dp[i][w] = dp[i - 1][w];
            }
        }
    }

    printf("\nMaximum Profit = %d\n", dp[n][W]);

    return 0;
}


/*
Time Complexity

Best Case:    O(n * W)
Average Case: O(n * W)
Worst Case:   O(n * W)


Space Complexity

O(n * W)
*/


/*
Conclusion:

The 0/1 Knapsack Problem was successfully implemented using
Dynamic Programming.

The DP table stores the maximum profit possible for each item
and capacity combination.

The algorithm has a time complexity of O(n * W) and a space
complexity of O(n * W).
*/